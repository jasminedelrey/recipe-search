
import React, { Component } from 'react';
import './Food.css';
import foodJson from '/Users/jasminedelreyes/Desktop/firstreact/comp355-hw3/src/Assets/data/recipe.json'

const foods = foodJson.recipes;
class SearchResults extends Component {
    constructor() {
        super();
        // this.state = {
        //     searchList : []
        // }
    }

    // handleResults() {
    //     let foodList = []
    //     let count = 0

    //     console.log("PROPS OF DIET: " + this.props.dietResultList[0])

    
    //     // this.setState({
    //     //   searchList: [...this.state.searchList, ...foodList],
    //     // });
        
    //     console.log(foodList);
    //     return foodList;
    
    //   }

    // handleDietMatch() {
    //     this.props.outputDietMatch(this.props.dietResultList[0], this.props.recipeResultList[0])
    //     return this.props.testList
    // }

    render() {
    
    // console.log("CURRENT STATE OF RESULT DICTIONARY: " + Object.entries(foodList))
    // const results = this.handleDietMatch;
    // console.log("CURRENT VALUE OF RESULTS"  + results)
    // console.log("PROPS OF DIET: " + this.props.dietResultList[0])
    // console.log("PROPS OF RECIPE: " + this.props.recipeResultList[0])
    // console.log("PROPS OF testList: " + this.props.testList[0])
    let results = this.props.searchList;
    let resultEntries = [];

        for(let i=0; i< results.length; i++) {
            resultEntries.push(
                <div className= "individual-search-results">
                <img src= {results[i].image}/>
                <h3> {results[i].title}</h3>
                <p>Servings: {results[i].servings} servings </p>
                <p>Prep Time: {results[i].prepTime} minutes</p>
                <p>Calories: {results[i].calories} calories </p>
                <p>Diet: {results[i].dietLabel}</p>
                <p>Recipe Category: {results[i].recipeCategory}</p>
                </div>
            )
        }
    return (
        <div className= "search-results">
        {resultEntries}
      </div>
    );
    }
}

  export default SearchResults;